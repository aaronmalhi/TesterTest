﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Text.RegularExpressions;
using System.Threading;
using System.Threading.Tasks;
using System.Drawing;
using Microsoft.VisualStudio.TestTools.UnitTesting;
using OpenQA.Selenium;
using OpenQA.Selenium.Firefox;
using OpenQA.Selenium.Support.UI;
using OpenQA.Selenium.Interactions;

/*

***********************************************************************
Code Author: Aaron Malhi
Description: Unit/Integration Tests for Bikes Testers Exercise (UI/Performance)
13/06/2018
***********************************************************************

*/

// This provides the first custom class select for 'Endurance' */
namespace SeleniumTests
{
    [TestClass]
    public class BikersTestCase
    {
        private static IWebDriver driver;
        private StringBuilder verificationErrors;
        private static string baseURL;
        private bool acceptNextAlert = true;
        private string link;

        [ClassCleanup]
        public static void CleanupClass()
        {
            try
            {
                //driver.Quit();// quit does not close the window
                driver.Close();
                driver.Dispose();
            }
            catch (Exception)
            {
                // Ignore errors if unable to close the browser
            }
        }

        [TestInitialize]
        public void InitializeTest()
        {
            verificationErrors = new StringBuilder();
        }

        [TestCleanup]
        public void CleanupTest()
        {
            Assert.AreEqual("", verificationErrors.ToString());
        }
        // The webpage is found by the suite, the Endurance, Race and Comfort task are all selected seperately and collaboratively through a click/select function, this is completed within 1 second and the function is set to sleep */
        [TestMethod]
        public void EnduranceSelectTest()
        {
            driver.Navigate().GoToUrl("http://172.25.136.145:8000/");
            driver.FindElement(By.XPath("//input[@value='df.value']")).Click();
            {
                driver.FindElement(By.LinkText(link)).Click();
                Thread.Sleep(1000);
            }
           
        }

        [TestMethod]
        public void EnduranceRaceSelectTest()
        {
            driver.Navigate().GoToUrl("http://172.25.136.145:8000/");
            driver.FindElement(By.XPath("(//input[@value='df.value'])[2]")).Click();
            {
                driver.FindElement(By.LinkText(link)).Click();
                Thread.Sleep(1000);
            }
        }


        [TestMethod]
        public void EnduranceRaceComfortSelectTest()
        {
            driver.Navigate().GoToUrl("http://172.25.136.145:8000/");
            driver.FindElement(By.XPath("(//input[@value='df.value'])[3]")).Click();
            {
                driver.FindElement(By.LinkText(link)).Click();
                Thread.Sleep(1000);
            }
        }

        [TestMethod]
        public void RaceSelectTest()
        {
            driver.Navigate().GoToUrl("http://172.25.136.145:8000/");
            driver.FindElement(By.XPath("(//input[@value='df.value'])[2]")).Click();
            {
                driver.FindElement(By.LinkText(link)).Click();
                Thread.Sleep(1000);
            }
        }

        [TestMethod]
        public void RaceComfortTest()
        {
            driver.Navigate().GoToUrl("http://172.25.136.145:8000/");
            driver.FindElement(By.XPath("(//input[@value='df.value'])[3]")).Click();
            {
                driver.FindElement(By.LinkText(link)).Click();
                Thread.Sleep(1000);
            }
        }

        [TestMethod]
        public void ComfortTest()
        {
            driver.Navigate().GoToUrl("http://172.25.136.145:8000/");
            driver.FindElement(By.XPath("(//input[@value='df.value'])[3]")).Click();
            {
                driver.FindElement(By.LinkText(link)).Click();
                Thread.Sleep(1000);
            }
        }

        private bool IsElementPresent(By by)
        {
            try
            {
                driver.FindElement(by);
                return true;
            }
            catch (NoSuchElementException)
            {
                return false;
            }
        }

        private bool IsAlertPresent()
        {
            try
            {
                driver.SwitchTo().Alert();
                return true;
            }
            catch (NoAlertPresentException)
            {
                return false;
            }
        }

        private string CloseAlertAndGetItsText()
        {
            try
            {
                IAlert alert = driver.SwitchTo().Alert();
                string alertText = alert.Text;
                if (acceptNextAlert)
                {
                    alert.Accept();
                }
                else
                {
                    alert.Dismiss();
                }
                return alertText;
            }
            finally
            {
                acceptNextAlert = true;
            }
        }
    }
}


