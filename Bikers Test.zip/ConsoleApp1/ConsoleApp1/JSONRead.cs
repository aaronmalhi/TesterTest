﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Newtonsoft.Json;
using Newtonsoft.Json.Linq;
using System.IO;

namespace jobject
{
    class Program
    {
        static void Main(string[] args)
        {
            // reading file as jobject
            string filename = @"C:\Users\AaronPatel\Documents\Testers Test\test-testers-master\app\bikes.json";
            JObject o1 = JObject.Parse(File.ReadAllText(filename));
            JArray items = (JArray)o1["items"];

            // defining a string to add to the json file
            string item = @"{'id': 8,

                             'name': 'SL Road',
                             'description': 'With the SL road, its quick and comfortable to work and you can even do a relaxing after work ride.',
                             'image': { 'thumb': 'https://jujhar.com/images/bikes/776400_overview.png',
                                        'large': 'https://jujhar.com/images/bikes/776400_light.jpg'},
                             'class': ['comfort']}";

            // converting string to JObject
            JObject item_json = JObject.Parse(item);
            
            // adding item to items
            items.Add(item_json);

            // removing item from
            items.RemoveAt(1);
            File.WriteAllText(filename, o1.ToString());

        }

    }

}

